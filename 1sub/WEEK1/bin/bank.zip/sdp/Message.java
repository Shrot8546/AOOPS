package sdp;


public class Message {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 
        Logger logger = Logger.getInstance();

        logger.log("Application started");
       
	}

}
